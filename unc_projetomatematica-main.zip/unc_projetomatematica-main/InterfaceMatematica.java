public interface InterfaceMatematica {
  public float somar(float n1, float n2);
  public float subtrair(float n1, float n2);
  public float multiplicar(float n1, float n2);
  public float dividir (float divisor, float dividendo);
  public double raiz (float numero);

}